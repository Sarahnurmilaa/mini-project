function hitungLuas() {
  var sisi = parseFloat(document.getElementById("sisi").value);
  var luas = sisi * sisi;

  // Calculate and display the result only if the input is valid
  if (!isNaN(sisi)) {
    document.getElementById("hasil").textContent = luas;
  } else {
    alert("Masukkan angka yang valid!");
  }
}

function clearHasil() {
  document.getElementById("hasil").textContent = "0";
  document.getElementById("sisi").value = "";
}

document.getElementById("hitung").addEventListener("click", hitungLuas);
document.getElementById("clear").addEventListener("click", clearHasil);
